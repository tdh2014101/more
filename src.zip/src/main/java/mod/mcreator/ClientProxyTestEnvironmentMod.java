

public class ClientProxyTestEnvironmentMod extends CommonProxyTestEnvironmentMod {

	@Override
	public void registerRenderers(TestEnvironmentMod ins) {
		ins.mcreator_0.registerRenderers();
		ins.mcreator_1.registerRenderers();
		ins.mcreator_2.registerRenderers();
		ins.mcreator_3.registerRenderers();
		ins.mcreator_4.registerRenderers();
		ins.mcreator_5.registerRenderers();
		ins.mcreator_6.registerRenderers();
		ins.mcreator_7.registerRenderers();
		ins.mcreator_8.registerRenderers();
		ins.mcreator_9.registerRenderers();
		ins.mcreator_10.registerRenderers();
		ins.mcreator_11.registerRenderers();
		ins.mcreator_12.registerRenderers();
		ins.mcreator_13.registerRenderers();
		ins.mcreator_14.registerRenderers();
		ins.mcreator_15.registerRenderers();
		ins.mcreator_16.registerRenderers();

	}
}
