

public class mcreator_VarList%MAINMODNAME%
