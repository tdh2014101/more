

public class CommonProxyTestEnvironmentMod {
	public void registerRenderers(TestEnvironmentMod ins) {
	}
}
