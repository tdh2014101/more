

public class mcreator_GlobalEventsTestEnvironmentMod {

}
